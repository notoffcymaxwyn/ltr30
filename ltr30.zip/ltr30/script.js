document.addEventListener("DOMContentLoaded", () => {
    const messageElement = document.querySelector(".message");
    const signatureElement = document.querySelector(".signature");
  
    const name = prompt("Masukkan nama teman:");
    const yourName = prompt("Masukkan nama Anda:");
    const customMessage = prompt("Tulis pesan Anda:");
  
    if (name) {
      messageElement.innerHTML = `Hai ${name},<br>${customMessage}`;
    }
  
    if (yourName) {
      signatureElement.textContent = `Salam hangat, ${yourName}`;
    }
  });
  